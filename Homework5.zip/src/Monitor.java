public class Monitor {
	 private String monitorSize;
	    private String color;
	    private String power;
	    Monitor(String monitorSize, String mcolor, String mpower) {
	        this.monitorSize = monitorSize;
	        this.color = mcolor;
	        this.power = mpower;
	    }
	    public void turnOn(){
	        System.out.println("Turning on the monitor.");
	    }
	    public void printInfo(){
	        System.out.println("The spec of monitor");
	        System.out.println("Size: "+this.monitorSize+"inch");
	        System.out.println("Color: "+this.color);
	        System.out.println("Power: "+this.power);
	    }
}
