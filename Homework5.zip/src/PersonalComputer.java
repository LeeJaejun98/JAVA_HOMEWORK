public class PersonalComputer {
	 private Computer computer;
	    private Monitor monitor;
	    PersonalComputer(String cpu, String memory, String hdd, String color, String power, String monitorSize, String mcolor, String mpower) {
	        computer = new Computer(cpu, memory, hdd, color, power);
	        monitor = new Monitor(monitorSize, mcolor, mpower);
	    }
	    public void turnOn(){
	        computer.turnOn();
	        monitor.turnOn();
	    }
	    public void printInfo(){
	        computer.printInfo();
	        monitor.printInfo();
	    }

	    public static void main(String[] args){
	        PersonalComputer pc = new PersonalComputer("Core i7","16GB","2TB","White","500W","24","Black","45W");
	        pc.turnOn();
	        pc.printInfo();
	    }
}
