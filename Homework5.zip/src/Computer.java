public class Computer {
	 private String cpu;
	    private String memory;
	    private String hdd;
	    private String color;
	    private String power;
	    Computer(String cpu, String memory, String hdd, String color, String power) {
	        this.cpu = cpu;
	        this.memory = memory;
	        this.hdd = hdd;
	        this.color = color;
	        this.power = power;
	    }
	    public void turnOn(){
	        System.out.println("Turning on the computer.");
	    }
	    public void printInfo(){
	        System.out.println("The spec of computer");
	        System.out.println("CPU: "+this.cpu);
	        System.out.println("Memory: "+this.memory);
	        System.out.println("HDD: "+this.hdd);
	        System.out.println("Color: "+this.color);
	        System.out.println("Power: "+this.power);
	    }
	
}
